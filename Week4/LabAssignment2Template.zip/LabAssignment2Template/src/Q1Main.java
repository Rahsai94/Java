public class Q1Main {
    public static void main(String[] args) {

    }
}
