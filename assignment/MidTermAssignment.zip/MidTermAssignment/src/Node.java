//HuffmanNode Class
public class Node {
    int item;
    String code;
    Node left;
    Node right;
}
