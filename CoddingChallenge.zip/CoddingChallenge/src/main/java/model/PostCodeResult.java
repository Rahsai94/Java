package model;
public class PostCodeResult {
    private int status;
    private PostCodeInfo result;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public PostCodeInfo getResult() {
        return result;
    }

    public void setResult(PostCodeInfo result) {
        this.result = result;
    }
}
