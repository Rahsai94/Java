package model;
public class PostCodeValidateStatus {
    //Class Members
    private boolean result;
    private int status;

    //Getter and Setter Method for class members


    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
