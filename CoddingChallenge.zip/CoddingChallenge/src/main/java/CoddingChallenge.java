public class CoddingChallenge {
    public static void main(String[] args) {
        PostcodeApp postcodeApp = new PostcodeApp();
    }
}
